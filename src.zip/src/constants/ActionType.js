export const GET_POSTS = "GET_POSTS"

export const POSTS_ERROR = "POSTS_ERROR"