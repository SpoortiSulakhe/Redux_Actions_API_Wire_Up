import * as ActionType from "../constants/ActionType";
import axios from "axios";

export const getData= () =>async (dispatch) => {
    await axios.get("http://jsonplaceholder.typicode.com/users")
    .then((response) => {
        dispatch({
            type: ActionType["GET_POSTS"],
            payload: response.data,

        });
    })
    .catch((error) => {
        dispatch({
            type: ActionType["POSTS_ERROR"],
            payload: error.response,
        });
    });
};